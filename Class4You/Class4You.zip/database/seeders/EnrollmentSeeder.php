<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Enrollment;

class EnrollmentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $cnt = 1;
        
        // while($cnt <= 33) {
        //     Enrollment::create([
        //         'UserID' => 9,
        //         'ClassID' => $cnt,
        //     ]);
        //     $cnt++;
        // }

        // $cnt = 34;
        
        // while($cnt <= 49) {
        //     Enrollment::create([
        //         'UserID' => 10,
        //         'ClassID' => $cnt,
        //     ]);
        //     $cnt++;
        // }

        // $cnt = 50;
        
        // while($cnt <= 97) {
        //     Enrollment::create([
        //         'UserID' => 8,
        //         'ClassID' => $cnt,
        //     ]);
        //     $cnt++;
        // }
    }
}
