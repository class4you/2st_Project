# 라라벨 한국어 언어팩

### 사용방법 (How to using)

```
# PROJECT_DIRECTOR/ 로 이동
$ git clone https://github.com/yousung/laravel-lang-ko.git resources/lang/ko
$ rm -rf resources/lang/ko/.git
```


### 언어팩이 PROJECT_DIRECTOR/lang 에 있는 경우,

```
# PROJECT_DIRECTOR/ 로 이동
$ git clone https://github.com/yousung/laravel-lang-ko.git lang/ko
$ rm -rf lang/ko/.git
```
