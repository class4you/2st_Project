<template>
    <div>
        <router-view></router-view>
    </div>
</template>

<script>

export default {
    name: 'AppComponent',

    beforeUpdate() {
    },

    created() {
    },

    updated() {
    },

    data() {
        return {
        };
    },

    methods: {
    },

    components: {
    },
}
</script>
<style>
    @import url('/css/common.css');
</style>