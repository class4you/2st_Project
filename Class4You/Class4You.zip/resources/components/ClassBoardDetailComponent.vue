<template>
    <div> 
        <div v-for="data in item" class="class_detail_visual">
            <div class="class_detail_container_box">
                <div class="class_detail_container">
                    <div class="class_detail_container_lr">
                        <div class="class_detail_container_l">
                            <div class="class_detail_container_l_img_cover">
                                <img src="/img/html/1st/html1.png" alt="">
                            </div>
                        </div>

                        <div class="class_detail_container_r">
                            <div class="class_detail_container_r_banner">
                                <div class="class_detail_container_r_banner_label">
                                    <span>NEW</span>
                                </div>
                                <span>게임 개발</span>
                            </div>
                            <div class="class_detail_container_r_title_box">
                                <h2 class="class_detail_container_r_title">
                                    {{ data.ClassTitle }}    
                                </h2>
                            </div>
                            <div class="class_detail_container_r_content_box">
                                <p class="class_detail_container_r_content">
                                    강의에 대한 간단 내용 강의에 대한 간단 내용강의에 대한 간단 내용 강의에 대한 간단 내용강의에 대한 간단 내용 강의에 대한 간단 내용강의에 대한 간단 내용 강의에 대한 간단 내용강의에 대한 간단 내용 강의에 대한 간단 내용
                                </p>
                            </div>
                            <div class="class_detail_container_r_info_box">
                                <span class="class_detail_container_r_info_star_box">
                                    <div class="class_detail_container_r_info_star">
                                        <div class="class_detail_container_r_info_star_inr">
                                            <span>☆</span>
                                            <span>☆</span>
                                            <span>☆</span>
                                            <span>☆</span>
                                            <span>☆</span>
                                        </div>
                                    </div>
                                    <span>(5.0)</span>
                                </span>
                                <span>수강생 수</span>
                            </div>
                            <div class="class_detail_container_r_language">
                                <span class="class_detail_container_r_language_icon">#</span>
                                <span>HTML</span>
                                <span>CSS</span>
                                <span>JS</span>
                                <span>PHP</span>
                            </div>
                            <div class="class_detail_container_r_payment_box">
                                <div class="class_detail_container_r_payment_price">
                                    <span>가격: 122312312원</span>
                                </div>
                                <div class="class_detail_container_r_payment_classes">
                                    <button>수강 신청</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="class_container">
            <!-- 강의 소개 -->
            <ul class="class_tabs">
                <li @click="clickFlgTab = 0;" class="class_tab_link current" data-tab="class_tab1">강의 소개</li>
                <li @click="clickFlgTab = 1;" class="class_tab_link" data-tab="class_tab2">수강평</li>
                <li @click="clickFlgTab = 2;" class="class_tab_link" data-tab="class_tab3">커뮤니티</li>
                <li @click="clickFlgTab = 3;" class="class_tab_link" data-tab="class_tab4">공지사항</li>
            </ul>

        <div v-if="clickFlgTab === 0">
            <div id="class_tab1" class="class_tab_content class_current">
                <p>tab content1</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
                <p>동해물과백두산이마르고닳도록하느님이보우하사우리나라만세</p>
            </div>
            
            <div class="class_tab_content_title">
                <p>기초 설명</p>
            </div>
            <div id="class_tab1" class="class_tab_content">
                <p>무궁화삼천리화려강산대한사람대한으로길이보전하세</p>
                <p>무궁화삼천리화려강산대한사람대한으로길이보전하세</p>
                <p>무궁화삼천리화려강산대한사람대한으로길이보전하세</p>
            </div>

            <div class="class_tab_content_title">
                <p>커리큘럼</p>
            </div>
            <div id="class_tab1" class="class_tab_content">
                <p>커리큘럼</p>
            </div>

            <div class="class_tab_content_title">
                <p>강의 특징</p>
            </div>
            <div id="class_tab1" class="class_tab_content">
                <p>강의 특징</p>
            </div>

            <div class="class_tab_content_title">
                <p>강사 설명</p>
            </div>
            <div id="class_tab1" class="class_tab_content">
                <p>강사 설명</p>
            </div>
        </div>

            <!-- 수강평 -->
        <div v-if="clickFlgTab === 1">    
            <div id="class_tab1" class="class_current class_detail_rating_form">
                <form action="">
                    <fieldset>

                        <div class="class_detail_rating_form_text">
                            <textarea name="" id="" cols="30" rows="10" placeholder="수강평을 작성해주세요."></textarea>
                        </div>

                        <div class="class_detail_rating_form_content">
                            <div class="class_detail_rating_form_star">
								<label>평점</label>
									<label for=""></label><span>☆</span>
									<label for=""></label><span>☆</span>
									<label for=""></label><span>☆</span>
									<label for=""></label><span>☆</span>
									<label for=""></label><span>☆</span>
                            </div>

                            <div class="class_detail_rating_form_button">
                                <button>수강평 작성</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </div>

            <div class="class_detail_rating_list">
				<div class="class_detail_rating_view_tab">
					<div class="class_detail_rating_tab_title">
						<span><a href="">최신순</a></span>
					</div>
					<div class="class_detail_rating_tab_title">
						<span><a href="">인기순</a></span>
					</div>
					<div class="class_detail_rating_tab_title">
						<span><a href="">조회순</a></span>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>내가 쓴글 수정삭제가능</p>
					</div>
					<div class="class_detail_rating_user_button">
						<div class="class_detail_rating_user_update_button">
							<button>수정</button>
						</div>
						<div class="class_detail_rating_user_delete_button">
							<button>삭제</button>
						</div>
					</div>
				</div>
			
			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>수업이 재밌어요</p>
					</div>
				</div>

			<hr>	

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>코딩 조아요</p>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>재밌는 라라벨</p>
					</div>
				</div>
        	</div>
        </div>

            <!-- 커뮤니티 -->
            
        <div v-if="clickFlgTab === 2">    
            <div id="class_tab1" class="class_current class_detail_rating_form">
                <form action="">
                    <fieldset>

                        <div class="class_detail_rating_form_text">
                            <textarea name="" id="" cols="30" rows="10" placeholder="강의에 대한 질문을 작성해주세요."></textarea>
                        </div>

                        <div class="class_detail_commu_form_content">

                            <div class="class_detail_rating_form_button">
                                <button>질문 작성</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </div>

            <div class="class_detail_rating_list">
				<div class="class_detail_rating_view_tab">
					<div class="class_detail_rating_tab_title">
                        <!-- 질문게시판 클릭시 커뮤니티 질문게시판 페이지로 이동 -->
						<span>
                            <a href="">질문게시판</a>
                        </span>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>내가 쓴글 수정삭제가능</p>
					</div>
					<div class="class_detail_rating_user_button">
						<div class="class_detail_rating_user_update_button">
							<button>수정</button>
						</div>
						<div class="class_detail_rating_user_delete_button">
							<button>삭제</button>
						</div>
					</div>
				</div>
			
			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>수업이 재밌어요</p>
					</div>
				</div>

			<hr>	

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>코딩 조아요</p>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>작성자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>재밌는 라라벨</p>
					</div>
				</div>
        	</div>
        </div>    

            <!-- 공지사항 -->
        
        <div v-if="clickFlgTab === 3">   
            <div id="class_tab1" class="class_tab_content class_current class_detail_notice_main">
				<div class="class_detail_notice_main_div">
					<div class="class_detail_notice_title">
						<p>메인 공지사항</p>
					</div>
					<div class="class_detail_notice_content">
						<p>집에가면머합니까남아서열심히하소</p>
						<p>그래도레이아웃작업은다해가지않슴니까?</p>
						<p>감사하다명호야</p>
						<p>근데 이거 늘어나나?</p>
						<p>늘어나긴하네</p>
						<p>div로 함더 묶을까 말까</p>
					</div>
				</div>
            </div>
            
            <div class="class_detail_rating_list">
				<div class="class_detail_rating_view_tab">
					<div class="class_detail_rating_tab_title">
                        <!-- 질문게시판 클릭시 커뮤니티 질문게시판 페이지로 이동 -->
						<span>이전 공지사항</span>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>관리자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						<p>css 이렇게 많이 써본건 처음이야</p>
						
					</div>
				</div>
			
			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>관리자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>수업이 재밌어요</p>
					</div>
				</div>

			<hr>	

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>관리자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>코딩 조아요</p>
					</div>
				</div>

			<hr>

				<div id="class_tab1" class="class_detail_rating_list_div">
					<div class="class_detail_rating_list_user">
						<div class="class_detail_rating_user_id">
							<p>관리자ID</p>
						</div>
						<div class="class_detail_rating_user_date">
							<p>2023-12-13</p>
						</div>
					</div>
					<div class="class_detail_rating_list_text">
						<p>재밌는 라라벨</p>
					</div>
				</div>
        	</div>
        </div> 

		</div>
        

        
    </div>
</template>
<script>
export default {
    name: 'ClassBoardDetailComponent',
    props: {
        data: Object,
    },
    data() {
        return {
            clickFlgTab: 0,
        }
    },
    
}
</script>
<style>
    
</style>