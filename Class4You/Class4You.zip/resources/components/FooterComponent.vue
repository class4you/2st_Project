<template>
    <div>
        <footer>

        </footer>
    </div>
</template>
<script>
export default {
    name: 'FooterComponent'
}
</script>
<style>
    
</style>