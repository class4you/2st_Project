

<?php $__env->startSection('classBoardMain'); ?>

<div id="wrap">

	<div class="class_main_visual">
		<img src="" alt="">
	</div>

	<hr>

	<div class="class_container_main">
		<main class="class_contents">
			<div class="class_main_mrap">
				
				<div class="class_main_new_text">
					<h3><?php echo e($msg); ?></h3>
				</div>
				
				<div class="main_container_new_box">
					<ul class="class_main_container_new">
					<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<a href="<?php echo e(route('classboarddetail', ['ClassID' => $item->ClassID])); ?>">
						<li class="class_main_container_new_card">
							<div class="class_main_container_new_card_img">
								<img src="<?php echo e(asset($item->ClassImg)); ?>" alt="">
							</div>
							<div class="class_main_container_new_card_title">
								<h4><?php echo e($item->ClassTitle); ?></h4>
							</div>
							<div class="class_main_container_new_card_content">
								<p><?php echo e($item->ClassDescription); ?></p>
							</div>

							<ul class="class_main_container_new_card_tag"> 
						<?php $__empty_2 = true; $__currentLoopData = $item->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>			
								<li><?php echo e($language->ClassLanguageName); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>	
						<?php endif; ?>		
							</ul>
						</li>
						</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>

					</ul>
				</div>
	
			</div>
		</main>
	</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('classBoard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2st_Project\Class4You\resources\views/classBoardViewAll.blade.php ENDPATH**/ ?>