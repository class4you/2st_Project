

<?php $__env->startSection('classBoardMain'); ?>



<div>
    <classBoardDetail-Component :data"<?php echo e($data); ?>"></classBoardDetail-Component>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('classBoard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\2st_Project\Class4You\resources\views/classBoardDetail.blade.php ENDPATH**/ ?>